package sa.site.lab.petstore.Animal;

public class Puppy{
    public Puppy(String name) {
       // super(name);
    }
    public void getName() {
        System.out.println("Puppy.getName");
        //return super.getName();
    }

    public void setName(String name) {
       // super.setName(name);
    }
}
