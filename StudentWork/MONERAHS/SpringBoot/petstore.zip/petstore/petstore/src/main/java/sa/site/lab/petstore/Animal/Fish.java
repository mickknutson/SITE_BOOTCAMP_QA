package sa.site.lab.petstore.Animal;

public class Fish {
    public Fish(String name) {
       // super(name);
    }
}
