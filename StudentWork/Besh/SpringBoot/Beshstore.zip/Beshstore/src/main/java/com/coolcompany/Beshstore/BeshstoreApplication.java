package com.coolcompany.Beshstore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BeshstoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(BeshstoreApplication.class, args);
	}

}
