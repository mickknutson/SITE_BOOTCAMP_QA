package sa.site.lab.petstore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PetstoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
